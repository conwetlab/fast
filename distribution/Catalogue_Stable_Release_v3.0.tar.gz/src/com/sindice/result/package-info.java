/**
 * This package contains all the classes modeling
 * the various query results.
 */
package com.sindice.result;