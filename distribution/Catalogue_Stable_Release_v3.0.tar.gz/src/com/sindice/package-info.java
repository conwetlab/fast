/**
 * This is the main package containing the
 * facade and related classes for
 * the <i>Sindice.com</i>.
 */
package com.sindice;