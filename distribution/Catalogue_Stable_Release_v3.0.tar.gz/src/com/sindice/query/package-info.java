/**
 * This package contains all the classes modeling
 * the various queries on <i>Sindice.com</i>
 */
package com.sindice.query;