This is the README for the FAST Catalogue prototype! 

For more information on the project in general see: 

http://fast.morfeo-project.eu/