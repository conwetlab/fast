/**
 * 
 */
package eu.morfeoproject.fast.catalogue;

/**
 * @author Ismael Rivera
 *
 */
public class OntologyReadonlyException extends Exception {

	/**
	 * 
	 */
	public OntologyReadonlyException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public OntologyReadonlyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public OntologyReadonlyException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public OntologyReadonlyException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
