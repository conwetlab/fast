/**
 * 
 */
package eu.morfeoproject.fast.catalogue;

/**
 * @author Ismael Rivera
 *
 */
public class OntologyImportsNotSatisfiedException extends Exception {

	/**
	 * 
	 */
	public OntologyImportsNotSatisfiedException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public OntologyImportsNotSatisfiedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public OntologyImportsNotSatisfiedException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public OntologyImportsNotSatisfiedException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
