package eu.morfeoproject.fast.catalogue;

public class DuplicatedScreenException extends Exception {

}
