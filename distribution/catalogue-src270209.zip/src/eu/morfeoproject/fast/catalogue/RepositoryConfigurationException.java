/**
 * 
 */
package eu.morfeoproject.fast.catalogue;

/**
 * @author Ismael Rivera
 *
 */
public class RepositoryConfigurationException extends Exception {

	/**
	 * 
	 */
	public RepositoryConfigurationException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public RepositoryConfigurationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public RepositoryConfigurationException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public RepositoryConfigurationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
