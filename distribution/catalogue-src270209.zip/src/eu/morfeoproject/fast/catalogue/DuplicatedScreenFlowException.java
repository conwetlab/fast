package eu.morfeoproject.fast.catalogue;

public class DuplicatedScreenFlowException extends Exception {

}
