/**
 * 
 */
package eu.morfeoproject.fast.catalogue;

/**
 * @author Ismael Rivera
 *
 */
public class OntologyInvalidException extends Exception {

	/**
	 * 
	 */
	public OntologyInvalidException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public OntologyInvalidException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public OntologyInvalidException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public OntologyInvalidException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
